function fnCallme(){
    alert("hi I am from external file")

}

function fnCallme1(){
    alert("hi i am from extarnal again")
}
