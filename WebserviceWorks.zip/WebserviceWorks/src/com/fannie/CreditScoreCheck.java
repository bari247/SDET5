package com.fannie;

import javax.jws.WebService;

@WebService(endpointInterface="com.fannie.ICreditScoreCheck")
public class CreditScoreCheck implements ICreditScoreCheck {

	@Override
	public String SayHi(String name) {
		return "Hi" + name + "this is for testing";
	}

	@Override
	public String checkCreditScore(String name, int score) {
		if(score < 400 )
			return "Sorry loan processing is not done: " + name;
		else if (score >=400 && score < 600)
		{return "your processign will take time: please wait : " + name;
		
		} else {
			return "congrats loan is in progress : " + name;
		}
	}

	@Override
	public boolean checkEligible(int score) {
		
		return score>600;
	}

}
