package com.fannie.step;

import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditScoreStep {
	
	@Given("Employee has a credit score")
	public void Employee_has_a_credit_score(){
		System.out.println("Employee has a credit score >>>>>>");
	}
	
	@And("it meets the bank standards")
	public void it_meets_the_bank_standards(){
		System.out.println("Emplee meets bank standars.....");
	}
	
	
	@When("customer has ([a-zA-Z]{1,}) time job")
	public void customer_has_full_time_job(String workTime){
		System.out.println("customer has -"+ workTime+ "- time job>>>>>>>>>");
	}
	
	@And ("is a govt employee")
	public void is_a_govt_employee(){
		System.out.println("is a govt employee>>>>>>>>>");
		
	}
	
	
	@Then ("sanction")
	public void sanction(){
		System.out.println("sanction loan >>>>>");
	}
	
	
	@But ("Should repay within 5 years")
	public void Should_repay_within_5_years(){
		System.out.println("Should repay within 5 years>>>>>>>>>");		
	}
	
	
	@And ("is a private employee")
	public void is_a_private_employee(){
		
	}

}
