package Assignment2;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class KeyFind {
	public static void main(String[] args) {
		try {
			// File Reading and making a map of keys & list of associated values
			BufferedReader br = new BufferedReader(new FileReader("C:/workspace1/Workspace/LabAssignments/list.txt"));
			String strLine = null;
			Map<String, List<String>> keyValuesMap = new HashMap<String, List<String>>();
			String[] tokenizedArray = null;
			while((strLine = br.readLine()) != null) {
				tokenizedArray = strLine.split("=");
				String key = tokenizedArray[0].trim();
				String tokenizedValues = tokenizedArray[1].trim();
				String[] values = tokenizedValues.split(",");
				List<String> lstValues = new ArrayList<String>();
				for (String value : values) {
					lstValues.add(value.trim());
				}
				keyValuesMap.put(key, lstValues);
			}			
			br.close();
			
			// Asking User Input
			System.out.println("Please type a or b and press Enter key");
			System.out.println("a. Ask for Word");
			System.out.println("b. Add Key & Values");
			BufferedReader brInput = new BufferedReader(new InputStreamReader(System.in));
			String aOrb = brInput.readLine().trim();
			if(aOrb.equalsIgnoreCase("a")) {
				System.out.println("Please type the key whose values to be printed and press Enter key");
				String enteredKey = brInput.readLine();
				if(keyValuesMap.get(enteredKey) != null) {
					List<String> values = keyValuesMap.get(enteredKey);
					for (String value : values) {
						System.out.println(value);
					}
				} else {
					System.out.println("Word Not Found");
				}
			} else if(aOrb.equalsIgnoreCase("b")) {
				System.out.println("Please enter key and values for e.g. locations=Ashburn,Herndon");
				String enteredKeyValues = brInput.readLine().trim();
				
				// Creating file writer for adding key & values if user selects 'b' option
				BufferedWriter bw = new BufferedWriter(new FileWriter("C:/workspace1/Workspace/LabAssignments/list.txt"));
				
				// Writing existing key & values
				Iterator<String> keysIterator = keyValuesMap.keySet().iterator();
				while(keysIterator.hasNext()) {
					String key = keysIterator.next();
					List<String> values = keyValuesMap.get(key);
					String commaSeparatedValues = "";
					for (String value : values) {
						if(commaSeparatedValues.equalsIgnoreCase("")) {
							commaSeparatedValues = value;
						} else {
							commaSeparatedValues = commaSeparatedValues + "," + value;
						}
					}
					bw.write(key+"="+commaSeparatedValues+"\n");
				}
				
				// Writing new key & values entered by user
				bw.write(enteredKeyValues);
				bw.flush();
				bw.close();
			} else {
				System.out.println("Invalid Option. Please run the program again");
			}
			
			System.out.println("\n\n============================Program Ended===========================");
		} catch(Exception e) {
			e.printStackTrace();
		}
	}


}
