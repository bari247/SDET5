package Assignment1;


public class Bus extends Vehicle{
	
	private int numberOfPassangers;
	private String source;
	private String destination;
	
	
	
//	public Bus(int numberOfPassangers, String source, String destination) {
//		this.numberOfPassangers = numberOfPassangers;
//		this.source = source;
//		this.destination = destination;
//	}


	public Bus(String color, int noOfWheels, String model, int fc, int numberOfPassangers, String source, String destination) {
		super(color, noOfWheels, model, fc);
		this.numberOfPassangers = numberOfPassangers;
		this.source = source;
		this.destination = destination;
	}
	
	
	//geters and setters
		
	public int getNumberOfPassangers() {
		return numberOfPassangers;
	}

	public void setNumberOfPassangers(int numberOfPassangers) {
		this.numberOfPassangers = numberOfPassangers;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	

	@Override
	public String toString() {
		return "Bus [numberOfPassangers=" + numberOfPassangers + ", source=" + source + ", destination=" + destination
				+ "]";
	}

	
	//defining specific methods for Bus
	
	public void departure(){
		System.out.println("This is a bus, that can be used for public transport");
	}
	
	public void noOfGears(){
		System.out.println("This truck has 4 gears");
	}

}
