package Assignment1;


public class Car extends Vehicle{
	private String transmission;

	
	
	public Car(String color, int noOfWheels, String model, int fc, String transmission) {
		super(color, noOfWheels, model, fc);
		this.transmission = transmission;
	}

	//getters and setters
	public String getTransmission() {
		return transmission;
	}

	public void setTransmission(String transmission) {
		this.transmission = transmission;
	}
	
	//To String
	
	@Override
	public String toString() {
		return super.toString() + "Car [transmission=" + transmission + "]";
	}

	// Specific method
	public void absBrake(){
		System.out.println("All cars in US have abs brake system");
	}

}
