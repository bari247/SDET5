package Assignment1;

public class Road {
	
	public static void main(String[] args) {
		Car fordCoupe = new Car("Red", 4, "focus", 26, "Automatic");
		Truck kenworth = new Truck("Blue", 18, "Kenworth", 100, 200);
		Bus amTrack = new Bus("Yellow", 8, "Volvo", 50, 32, "Ashburn", "NY");
		
		
		System.out.println("----------Car info here-----------");
		System.out.println(fordCoupe);
		
		//Calling Common method
		fordCoupe.accelerate();
		
		//Calling speicfic method
		fordCoupe.absBrake();
		
		
	}

}
