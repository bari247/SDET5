package Assignment1;


public class Vehicle {
	private String color;
	private int noOfWheels;
	private String model;
	private int fuelCapacity;
	
	
	//this is non-parameterized consturctor
	public Vehicle() {
		
	}
	
	
	// this is parameterized constructor
	public Vehicle(String color, int noOfWheels, String model, int fc){
		this.color = color;
		this.noOfWheels = noOfWheels;
		this.model = model;
		this.fuelCapacity =fc;
		
		//System.out.println("Hello World");
	}
	
	

	// getter and setters....
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getNoOfWheels() {
		return noOfWheels;
	}
	public void setNoOfWheels(int noOfWheels) {
		this.noOfWheels = noOfWheels;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	
	
	public int getFuelCapacity() {
		return fuelCapacity;
	}


	public void setFuelCapacity(int fuelCapacity) {
		this.fuelCapacity = fuelCapacity;
	}


	@Override
	public String toString() {
		return "Vehicle [color=" + color + ", noOfWheels=" + noOfWheels + ", model=" + model + "]";
	}
	
	
	public void brake() {
		
		System.out.println("This vehicle is going to stop");
		
	}
	
	public void accelerate(){
		System.out.println("This vehicle is speeding up");
	}
	
	
	
	
//	public static void main(String[] args) {
//		Vehicle v = new Vehicle();
//		
//		v.color = "Red";
//		
//		System.out.println(v);
//	}
	
}
