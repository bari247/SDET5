package Assignment1;


public class Truck extends Vehicle{
	private int loadCapacity;


	public Truck(String color, int noOfWheels, String model, int fc, int loadCapacity) {
		super(color, noOfWheels, model, fc);
		
		this.loadCapacity = loadCapacity;
	}

	//getters and setters
	
	public int getLoadCapacity() {
		return loadCapacity;
	}

	public void setLoadCapacity(int loadCapacity) {
		this.loadCapacity = loadCapacity;
	}

	@Override
	public String toString() {
		return "Truck [loadCapacity=" + loadCapacity + "]";
	}
	
	//Specific methods for truck
	
	public void noOfGears(){
		System.out.println("This truck has 14 gears");
	}

}
