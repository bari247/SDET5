package com.fannie.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import com.fannie.beans.Greetings;

@Path ("hello")
public class HelloResource {
	
//	@GET
//	public String sayHello(){
//		return "hello  from rest resournce";
//		
//	}
	
	
//	@GET
//	@Produces("text/html")
//	public String sayHello(){
//		
//		return "<html><body><h2>welcome to HTML </h2></body></html>";
//		
//	}
	
//	@GET
//	@Produces("application/xml")
//	public String sayHelloAsXML(){
//		return "<?xml version='1.0'?><message>Hello World2</message>";
//		
//	}
	
	
	@GET
	@Produces({"application/json"})
	public Greetings sayHelloJson(){
		Greetings g = new Greetings();
		g.setName("Harry");
		g.setMessage("Welcome to web service");
		
		return g;
		
	}
	
	

}
