package com.fannie.utility;

public interface Driver {
	/* Keys */
	String CHROME  = "webdriver.chrome.driver";
	String FIREFOX = "webdriver.gecko.driver";
	String IE = "webdriver.ie.driver";
	String PHANTOM="phantomjs.binary.path";
	
	
	/* Path  */
	
	String CHROME_PATH = "C:\\Software\\SDET5-SeleniumSoftware\\driver\\chromedriver_win32\\chromedriver.exe";
	String FIREFOX_PATH = "C:\\Software\\SDET5-SeleniumSoftware\\driver\\geckodriver-v0.16.1-win64\\geckodriver.exe";
	String IE_PATH = "C:\\Software\\SDET5-SeleniumSoftware\\driver\\IEDriverServer_x64_3.4.0\\IEDriverServer.exe";
	String PHANTOM_PATH="C:\\Software\\SDET5-SeleniumSoftware\\driver\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe";
}
