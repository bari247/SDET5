package com.fannie.utility;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

//this class shall have explicit wait for any location......
public class WaitTypes {

		private WebDriver driver;
		
		public  WaitTypes (WebDriver driver) {
			
			this.driver = driver;
			
		}
		
		
		// we will have methods which returns the welement on demand of explicit wait
		
		
		
		//this method will return webelemnt when it is available on webpage		
		public WebElement presenceOfElementLocated(By locator, int timeout){
			
			try {
				WebDriverWait wait = new WebDriverWait(driver, 20);
				
				WebElement element = wait.until(				
					ExpectedConditions.presenceOfElementLocated(locator)	
						);
				
				System.out.println("Element Located");
			} catch (Exception e) {
				System.out.println("Element not located" + e);
			}
			
			return null;		
			
			
			
			//return null;
			}
		
		public WebElement waitForElement(By locator, int timeout){
			try {
				WebDriverWait wait = new WebDriverWait(driver, 20);
				
				WebElement element = wait.until(				
					ExpectedConditions.visibilityOfElementLocated(locator)	
						);
				
				System.out.println("Element Located");
			} catch (Exception e) {
				System.out.println("Element not located" + e);
			}
			
			return null;			
		}
}
