package com.fannie.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class FlightPagePOMFactory {
	private WebDriver driver;
	
	public FlightPagePOMFactory(WebDriver driver){
		this.driver = driver;
		
		PageFactory.initElements(driver, this);		
	}
	
	@FindBy(id="tab-flight-tab-hp")
	WebElement flightsTab;
	
	@FindBy(id="flight-origin-hp-flight")
	WebElement flyFrom;
	
	@FindBy(id="flight-destination-hp-flight")
	WebElement flyTo;
	
	@FindBy(id="flight-departing-hp-flight")
	WebElement departDate;
	
	
	@FindBy(id="flight-returning-hp-flight")
	WebElement returnDate;
	
	
	@FindBy(xpath="//*[@id=\"gcw-flights-form-hp-flight\"]/div[8]/label/button")
	WebElement serachButton;
	
	public void clickFlightTab(){
		flightsTab.click();
	}
	
	public void sendFlyFrom(String flyFromVar){
		flyFrom.clear();
		flyFrom.sendKeys(flyFromVar);	
	}
	
	public void sendFlyTo(String flyToVar){
		flyTo.clear();
		flyTo.sendKeys(flyToVar);	
	}
	
	public void sendDepartDate(String departDateVar){
		departDate.click();
		departDate.clear();
		departDate.sendKeys(departDateVar);	
	}
	
	public void sendReturnDate(String returnDateVar){
		returnDate.click();
		returnDate.clear();
		returnDate.sendKeys(returnDateVar);
	}
	
	public void clickSearchButton(){
		serachButton.click();
	}

}
