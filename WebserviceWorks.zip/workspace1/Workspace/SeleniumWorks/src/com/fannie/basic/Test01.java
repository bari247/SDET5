package com.fannie.basic;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Test01 {
	public static void main(String[] args) {
		
		
		/*  Load the driver  */	
		
		WebDriver driver;
		
		/* This is for firefox */		
		// if the driver below does not work, we will use the one listed in second line (marionette)
		System.setProperty("webdriver.gecko.driver", "C:\\Software\\SDET5-SeleniumSoftware\\driver\\geckodriver-v0.16.1-win64\\geckodriver.exe");
		
		//or use this
		// System.setProperty("webdriver.firefox.marionette", "C:\\Software\\SDET5-SeleniumSoftware\\driver\\geckodriver-v0.16.1-win64\\geckodriver.exe");

		driver = new FirefoxDriver();		
		
		
		/*This is chrome driver setup */
//		System.setProperty("webdriver.chrome.driver", "C:\\Software\\SDET5-SeleniumSoftware\\driver\\chromedriver_win32\\chromedriver.exe");
//					
//		driver = new ChromeDriver();
		
		
		/* This is IE browser setup  */
		//System.setProperty(key, value)
		
		
				
		/* Open the browser for the driver */
		
		String baseUrl = "http://google.com";
		driver.get(baseUrl);
				
		/* Do some tasks */
		
		System.out.println("Title - > " + driver.getTitle());
		
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		


		/* Close the browser */
		
		driver.close();
	}

}
