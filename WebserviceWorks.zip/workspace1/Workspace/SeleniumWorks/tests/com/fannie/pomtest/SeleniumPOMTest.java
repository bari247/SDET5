package com.fannie.pomtest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.fannie.pom.FlightPagePOMFactory;
import com.fannie.utility.DriverFactory;
import com.fannie.utility.DriverNames;

public class SeleniumPOMTest {
	
	WebDriver driver;
	String BaseUrl;
	FlightPagePOMFactory flightFactory;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		driver = DriverFactory.getDriver(DriverNames.CHROME);		
		flightFactory = new FlightPagePOMFactory(driver);
		BaseUrl = "https://www.expedia.com";
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(2000);
		driver.quit();
	}

	@Test
	public void test() {
		
		driver.get(BaseUrl);
		flightFactory.clickFlightTab();
		flightFactory.sendFlyFrom("Washington, DC (IAD-Washington Dulles Intl.)");
		flightFactory.sendFlyTo("San Francisco, CA (SFO-San Francisco Intl.)");
		flightFactory.sendDepartDate("06/27/2017");
		flightFactory.sendReturnDate("06/29/2017");
		flightFactory.clickSearchButton();
		
	}

}
