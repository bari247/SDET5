package com.fannie.pomtest;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import com.fannie.pom.FlightPagePOM;
import com.fannie.utility.DriverFactory;
import com.fannie.utility.DriverNames;

public class FlightPageTest {
	
	WebDriver driver;
	//FlightPagePOM flightPage;
	String baseURL;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
	}

	@Before
	public void setUp() throws Exception {
		driver = DriverFactory.getDriver(DriverNames.PHANTOM);
		baseURL = "https://www.expedia.com";
		
	}

	@After
	public void tearDown() throws Exception {
		Thread.sleep(1000);		
		driver.quit();		
	}

	@Test
	public void test() {
		//flightPage.clickFlightTab(driver);
		
		driver.get(baseURL);
		FlightPagePOM.clickFlightTab(driver);
		FlightPagePOM.flyFromTextBox("Washington, DC (IAD-Washington Dulles Intl.)", driver);
		FlightPagePOM.flyToTextBox("San Francisco, CA (SFO-San Francisco Intl.)", driver);
		FlightPagePOM.flyFromDate("06/25/2017", driver);
		FlightPagePOM.flyReturnDate("06/27/2017", driver);
		FlightPagePOM.submitFlight(driver);
	}

}
