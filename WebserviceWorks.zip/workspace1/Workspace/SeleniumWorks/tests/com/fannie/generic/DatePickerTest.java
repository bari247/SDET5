package com.fannie.generic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.fannie.generics.GenericMethods;
import com.fannie.utility.Driver;
import com.fannie.utility.WaitTypes;

public class DatePickerTest {
	WebDriver driver;
	String baseURL;
	GenericMethods genericMethod;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
		
	}

	@Before
	public void setUp() throws Exception {
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		
		driver = new ChromeDriver(options);
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		baseURL = "https://www.expedia.com";		
		genericMethod = new GenericMethods(driver);
		driver.get(baseURL);
	}

	@After
	public void tearDown() throws Exception {
		
		Thread.sleep(1000);		
		//driver.quit();
	}
	
	
	@Ignore
	@Test
	public void test() throws InterruptedException {
		//WebElement departDate = genericMethod.getElement(".//*[@id='package-departing-wrapper-hp-package']/div/div/div[2]/table/tbody/tr/td/button[text()='10']", "xpath");
		
//		List<WebElement> dateRange = driver.findElements(By.xpath(".//*[@id='package-departing-wrapper-hp-package']/div/div/div[2]/table/tbody/tr/td/button"));
//		
//		System.out.println(dateRange.size());
		
		genericMethod.getElement("tab-flight-tab-hp", "id").click();
		
		genericMethod.getElement("flight-departing-hp-flight", "id").clear();
		genericMethod.getElement("flight-departing-hp-flight", "id").click();
		
		String locator = ".//*[@id='flight-departing-wrapper-hp-flight']/div/div/div[2]/table/tbody/tr/td/button[not(@disabled)]";
		String type = "xpath";
		
		if(genericMethod.checkSingleEntry(locator, type)){
			
			WebElement departDate = genericMethod.getElement(locator, type);
			
			departDate.click();
			
		}else{
			List<WebElement> dateList = new ArrayList<WebElement>();
			
			dateList = genericMethod.getElementsAsList(locator, type);
			
			for (WebElement temp : dateList){
				
				System.out.println(temp.getText());
//				temp.click();
//				genericMethod.getElement("flight-departing-hp-flight", "id").clear();
//				
//				Thread.sleep(2000);
//				//genericMethod.getElement("flight-departing-hp-flight", "id").click();
//				
//				driver.findElement(By.id("flight-departing-hp-flight")).click();
			}
		}
	}

	
	@Test
	public void getFlyingFromListTest() throws InterruptedException{
		String partial = "new";
		String partial2 = "san";
		
		genericMethod.getElement("tab-flight-tab-hp", "id").click();
		genericMethod.getElement("flight-origin-hp-flight", "id").clear();
		genericMethod.getElement("flight-origin-hp-flight", "id").sendKeys(partial);
		
		Thread.sleep(3000);
		
		List<WebElement> elements1 = genericMethod.getElementsAsList("results-item", "class");
		List<String> flyFromStringList = new ArrayList<String>();
		
		for (WebElement temp : elements1){
			flyFromStringList.add(temp.getText());
		}
		
		
		genericMethod.getElement("flight-destination-hp-flight", "id").clear();
		genericMethod.getElement("flight-destination-hp-flight", "id").sendKeys(partial2);
		Thread.sleep(3000);
		List<WebElement> elements2 = genericMethod.getElementsAsList("results-item", "class");		
		List<String> flyToStringList = new ArrayList<String>();
		
		for (WebElement temp : elements2){
			flyToStringList.add(temp.getText());
		}
		
		//System.out.println(elements1.size());
		
	}
}
