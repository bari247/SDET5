package com.fannie.generic;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fannie.generics.GenericMethods;
import com.fannie.utility.Driver;
import com.fannie.utility.WaitTypes;

import junit.framework.Assert;

public class GenericExample {

	WebDriver driver;
	String baseURL;
	WaitTypes waitTypes;
	GenericMethods genericMethod;
	

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
		
	}

	@Before
	public void setUp() throws Exception {
		
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--start-maximized");

		Map<String, Object> prefs = new HashMap<String, Object>();
		prefs.put("credentials_enable_service", false);
		prefs.put("profile.password_manager_enabled", false);
		options.setExperimentalOption("prefs", prefs);

		DesiredCapabilities capabilities = DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		
		
		
		
		
		
		driver = new ChromeDriver(options);
		//driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		baseURL = "http://webmail.sdettraining.com//Login.aspx";
		waitTypes = new WaitTypes(driver);
		genericMethod = new GenericMethods(driver);
		driver.get(baseURL);
	}

	@After
	public void tearDown() throws Exception {
		
		Thread.sleep(1000);		
		driver.quit();
	}
	
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void test() {
		
		genericMethod.getElement("ctl00_MPH_txtUserName", "id").sendKeys("cohort311@sdettraining.com");
		
		genericMethod.getElement("ctl00_MPH_txtPassword", "id").sendKeys("H@m##d@7860");
		
		genericMethod.getElement("btnLogin", "id").click();
		
		
		
		//driver.switchTo().frame("/Main/frmToday.aspx");
		
		
		
		
		
		

		
		
		
		//driver.get("http://webmail.sdettraining.com/Main/frmToday.aspx");
		
		driver.switchTo().frame("ctl00_Split_Frame_ContentFrame");
		
		
		
		//String bodyText = genericMethod.getElement("//*[@id=\"PageHeader\"]/h1", "xpath").getAttribute("value");
		
		String bodyText = driver.findElement(By.id("ctl00_MPH_calendarToday__Label")).getText();
		System.out.println(bodyText);
		//Assert.assertTrue("Text not found!", bodyText.contains("Calendar"));
		
		
		
		
		Assert.assertTrue("Testing", bodyText.contains("Calendar"));
		
		//*[@id="ctl00_MPH_calendarToday__Label"]
		
		//*[@id="ctl00_TitleBar_UpdatePanel3"]
		
		//ctl00_MPH_calendarToday__Label
		
	}
		
}
