package com.fannie.basics;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fannie.utility.Driver;


@RunWith(Parameterized.class)
public class ParameterizedClassEx01 {
	
	private String fromAirport;
	private String toAirport;
	
	
	public ParameterizedClassEx01(String fromAirport, String toAirport) {
		super();
		this.fromAirport = fromAirport;
		this.toAirport = toAirport;
	}
	
	
	////@Parameterized.Parameter
	//public static Collection SourceDestination(){
		
	//}


	WebDriver driver;
	String baseURL;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
		
	}

	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		baseURL = "https://www.expedia.com";
		driver.get(baseURL);
	}

	@After
	public void tearDown() throws Exception {
		
		Thread.sleep(1000);		
		driver.quit();
	}


	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
