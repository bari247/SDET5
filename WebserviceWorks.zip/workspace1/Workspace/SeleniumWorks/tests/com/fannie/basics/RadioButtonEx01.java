package com.fannie.basics;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.fannie.utility.Driver;

import java.util.List;

public class RadioButtonEx01 {

	WebDriver driver;
	String baseURL;
	String baseURL2;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
		
	}

	@Before
	public void setUp() throws Exception {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
		baseURL = "http://naveenks.com/selenium/RegForm.html";
		
		driver.get(baseURL);
	}

	@After
	public void tearDown() throws Exception {
		
		Thread.sleep(1000);		
		driver.quit();
	}



	@Test
	public void test() {
		
		
		List<WebElement> radioGroup1 = driver.findElements(By.name("genderRadio"));
		//WebElement radioGroup = driver.findElement(By.name("genderRadio"));
		
		
		WebElement FemaleRadio = driver.findElement(By.id("genderFemale"));		
		FemaleRadio.click();
		

		
//		for(int i=0; i < radioGroup1.size(); i++){
//			
//			System.out.println(radioGroup1.get(i).getTagName());
//			System.out.println(radioGroup1.get(i).isSelected());
//			
//		}
		
		for(WebElement temp : radioGroup1){
			System.out.println(temp.getAttribute("value")+ " is " + temp.isSelected());
			
			//radioGroup1.
		}
		 
		
	}
	
	@Test
	public void getAttributeValue (){
		WebElement  element= driver.findElement(By.xpath("/html/body/div[1]/form/div[13]/div/input[1]"));
		
		String elementText = element.getAttribute("value");
		
		System.out.println(elementText);
	}
}
