package com.fannie.basics;


import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.fannie.utility.Driver;

public class PayPal1{
	private WebDriver driver;
	private String baseUrl;
	
	
	  @BeforeClass
		public static void setUpBeforeClass() throws Exception {
			System.setProperty(Driver.CHROME, Driver.CHROME_PATH);
			
		}
	
	@Before
	  public void setUp() throws Exception {
	    driver = new ChromeDriver();
	    baseUrl = "https://www.paypal.com/";
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	  }
	
	  @Test
	  public void testUntitled2() throws Exception {
	    driver.get(baseUrl + "/us/home");
	    driver.findElement(By.id("ul-btn")).click();
	    driver.findElement(By.id("email")).clear();
	    driver.findElement(By.id("email")).sendKeys("bari247@hotmail.com");
	    driver.findElement(By.id("password")).clear();
	    driver.findElement(By.id("password")).sendKeys("xyz");
	    driver.findElement(By.id("btnLogin")).click();
	    
	    String bodyText = driver.findElement(By.tagName("body")).getText();
	    Assert.assertTrue("Text not found!", bodyText.contains("Some of your info isn't correct. Please try again.")); 
	    
	    		
	  }
	
	  @After
	  public void tearDown() throws Exception {
	    
	    Thread.sleep(1000);
	    driver.quit();
	  }
	
}

