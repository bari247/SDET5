package com.evening.homework;

public class ForEachPrintMonth {
//	public static void main(String[] args) {
//		for (int i=1; i<12; i++){
//			
//			if(i==1){
//				System.out.println("Month is january");
//				
//			}
//			
//			if(i==2){
//				System.out.println("Month is february");
//				
//			}
//			
//			if(i==3){
//				System.out.println("Month is march");
//				
//			}
//			
//			if(i==4){
//				System.out.println("Month is april");
//				
//			}
//			
//			if(i==5){
//				System.out.println("Month is may");
//				
//			}
//			
//			if(i==6){
//				System.out.println("Month is june");
//				
//			}
//			
//			if(i==7){
//				System.out.println("Month is july");
//				
//			}
//			
//			if(i==8){
//				System.out.println("Month is august");
//				
//			}
//			
//			if(i==9){
//				System.out.println("Month is september");
//				
//			}
//			
//			if(i==10){
//				System.out.println("Month is october");
//				
//			}
//			
//			if(i==11){
//				System.out.println("Month is november");
//				
//			}
//			
//			if(i==12){
//				System.out.println("Month is december");
//				
//			}
//			
//			
//		}
//			
//				
//	}

}
