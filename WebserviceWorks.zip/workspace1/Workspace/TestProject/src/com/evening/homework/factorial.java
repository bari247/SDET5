package com.evening.homework;

public class factorial {

public static void main(String[] args) {
	
	int i = 8;
	int x=0;
	int factorial  = 1;
	for (x=1; x<i; x++){
		factorial = factorial*x;
	}
	
	System.out.println(factorial);
			
}


}
