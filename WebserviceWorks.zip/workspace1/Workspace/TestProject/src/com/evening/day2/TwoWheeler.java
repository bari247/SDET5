package com.evening.day2;

public class TwoWheeler extends Vehicle{

}
