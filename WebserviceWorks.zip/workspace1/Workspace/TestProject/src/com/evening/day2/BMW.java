package com.evening.day2;

public class BMW extends FourWheeler{

}
