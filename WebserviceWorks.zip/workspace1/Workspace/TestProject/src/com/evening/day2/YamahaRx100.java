package com.evening.day2;

public class YamahaRx100 extends TwoWheeler {

}
