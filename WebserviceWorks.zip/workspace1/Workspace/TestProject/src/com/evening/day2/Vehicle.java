package com.evening.day2;

public class Vehicle {

}
