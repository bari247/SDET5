package com.evening.day2;

public class Ford extends FourWheeler{

}
