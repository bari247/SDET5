package com.evening.day2;

public class KawasakiNinja extends TwoWheeler{

}
