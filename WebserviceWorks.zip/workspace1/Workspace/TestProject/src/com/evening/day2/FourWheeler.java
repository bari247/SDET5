package com.evening.day2;

public class FourWheeler extends Vehicle{

}
