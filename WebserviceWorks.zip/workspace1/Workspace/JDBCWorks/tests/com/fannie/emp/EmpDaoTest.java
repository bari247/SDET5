package com.fannie.emp;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import com.fannie.beans.Employee;
import com.fannie.contract.IEmpDAO;
import com.fannie.dao.EmpDAO;

import junit.framework.Assert;

public class EmpDaoTest {

	@SuppressWarnings("deprecation")
	@Test
	public void empInsertTest(){
		Employee emp = new Employee(200, "Kausar", 2000, "kawsar@hotmail.com");
		IEmpDAO dao = new EmpDAO();
		
		Assert.assertEquals(true, dao.insertEmp(emp));
		
		
	}

}
