package com.fannie.client;

import com.fannie.beans.Employee;
import com.fannie.contract.IEmpDAO;
import com.fannie.dao.EmpDAO;

public class EmpClient {
	public static void main(String[] args) {
//		Employee emp = new Employee(101, "Charry", 1231, "harry@test.com");
		IEmpDAO dao = new EmpDAO();
//		
//		System.out.println(dao.insertEmp(emp)?"Inserted":"Sorry not inserted");
//		
//		dao.delete(101);
		
//		Employee fetchedEmp = dao.getEmp(102);
//		System.out.println(fetchedEmp);
		
		for (Employee temp : dao.getAllEmps()) {
		    System.out.println(temp);
		}
		
	}

}
