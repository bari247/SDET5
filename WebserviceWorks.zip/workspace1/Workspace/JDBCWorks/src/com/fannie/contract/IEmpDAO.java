package com.fannie.contract;

import java.util.List;

import com.fannie.beans.Employee;
import com.fannie.connection.getConnection;

public interface IEmpDAO {
	// CRUD - Create, REad, Update, Delete
	
	//Insert
	public boolean insertEmp(Employee emp);
	

	//update
	public boolean updateEmp(int empId, double salary);
	
	//delete
	public boolean delete(int empID);
	
	//get 1 employee
	public Employee getEmp(int empID);
	
	
	//get all
	public List<Employee> getAllEmps();
	
	

}
