package com.fannie.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class getConnection {
	static Connection conn = null;
	public PreparedStatement ps, ps1;
	public ResultSet rs;
	
	
	//This code sets the connection for mysql database sdet5, for root user.
	
	public static Connection getMySQLConnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost/sdet5", "root", "hexaware");
			
			return conn;
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
		
		return null;
		
	}
	
	

}
