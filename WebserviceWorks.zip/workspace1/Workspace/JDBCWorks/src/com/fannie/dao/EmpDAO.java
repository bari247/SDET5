package com.fannie.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fannie.beans.Employee;
import com.fannie.connection.getConnection;
import com.fannie.contract.IEmpDAO;

public class EmpDAO implements IEmpDAO {

	public boolean insertEmp(Employee emp) {
		String sql = "insert into emp values(?,?,?,?)";

		getConnection gc = new getConnection();

		try {
			gc.ps = getConnection.getMySQLConnection().prepareStatement(sql);
			gc.ps.setInt(1, emp.getEmpId());
			gc.ps.setString(2, emp.getEmpName());
			gc.ps.setDouble(3, emp.getEmpSal());
			gc.ps.setString(4, emp.getEmail());

			if (gc.ps.executeUpdate() > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public boolean updateEmp(int empId, double salary) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(int empID) {
		String sql2 = "delete from emp where empid = ?";
		getConnection gc = new getConnection();

		try {
			gc.ps = getConnection.getMySQLConnection().prepareStatement(sql2);
			gc.ps.setInt(1, empID);
			if (gc.ps.executeUpdate() > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	public Employee getEmp(int empID) {
		String sql = "select empid, empname, empsal, email from emp where empid=?";
		getConnection gc = new getConnection();
		try {
			gc.ps = getConnection.getMySQLConnection().prepareStatement(sql);
			gc.ps.setInt(1, empID);

			gc.rs = gc.ps.executeQuery();

			if (gc.rs.next()) {
				Employee temp = new Employee();

				temp.setEmpId(gc.rs.getInt(1));
				temp.setEmpName(gc.rs.getString(2));
				temp.setEmpSal(gc.rs.getDouble("empsal"));
				temp.setEmail(gc.rs.getString(4));

				return temp;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

	public List<Employee> getAllEmps() {
		String sql = "select empid, empname, empsal, email from emp";
		getConnection gc = new getConnection();

		List<Employee> list = new ArrayList<Employee>();

		try {
			gc.ps = getConnection.getMySQLConnection().prepareStatement(sql);

			gc.rs = gc.ps.executeQuery();

			// iterate all the recoreds got from the above query

			while (gc.rs.next()) {

				Employee temp = new Employee();
				temp.setEmpId(gc.rs.getInt(1));
				temp.setEmpName(gc.rs.getString(2));
				temp.setEmpSal(gc.rs.getDouble(3));
				temp.setEmail(gc.rs.getString(4));

				list.add(temp);
			}
			return list;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return null;
	}

}
