package HomeWorkVehicle;

public class absVehicleDescription {
	public static void main (String[] args){
		
		absCar cars[] = new absCar[2];
		cars[0] = new absFordCoupe();
		cars[1] = new absFordCoupe();
		
		absCarBL cbl = new absCarBL();
		cbl.showCar(cars);
	}

}
