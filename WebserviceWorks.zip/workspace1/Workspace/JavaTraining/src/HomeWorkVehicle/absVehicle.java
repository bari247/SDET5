package HomeWorkVehicle;

public class absVehicle {
	
	int noOfWheels;

	public int setNoOfWheels(int wheels){
		return wheels;
	};
	
	public void brake(){
		System.out.println("All vehicles can apply break");
	}

}
