package HomeWorkVehicle;

public class absFordCoupe extends absCar {
	

	@Override
	public void numDoors() {
		System.out.println("Ford Coupe has 2 doors");
		
	}

	@Override
	public void speed() {
		System.out.println("Ford Coupe drives at avg speed");
		
	}

//	@Override
//	public void absWheels() {
//		System.out.println("It has 4 wheels and 2 axels");
//		
//	}	

}
	
	
