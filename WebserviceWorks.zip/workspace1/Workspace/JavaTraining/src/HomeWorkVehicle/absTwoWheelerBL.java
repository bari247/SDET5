package HomeWorkVehicle;

public class absTwoWheelerBL {

}
