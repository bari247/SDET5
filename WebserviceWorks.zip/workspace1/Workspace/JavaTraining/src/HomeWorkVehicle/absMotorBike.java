package HomeWorkVehicle;

public class absMotorBike {

}
