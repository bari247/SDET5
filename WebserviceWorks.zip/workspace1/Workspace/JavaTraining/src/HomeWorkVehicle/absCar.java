package HomeWorkVehicle;

public abstract class absCar extends absVehicle {
	
	public abstract void numDoors();
	public abstract void speed();
	
	public void fuelCapacity(int capacity) {
	System.out.println("Car fuel capacity" + capacity);
	}

}
