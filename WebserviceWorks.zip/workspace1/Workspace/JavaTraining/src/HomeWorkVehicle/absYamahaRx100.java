package HomeWorkVehicle;

public class absYamahaRx100 {

}
