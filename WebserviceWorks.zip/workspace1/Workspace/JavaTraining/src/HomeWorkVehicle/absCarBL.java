package HomeWorkVehicle;

public class absCarBL {
	public void showCar (absCar[] cars){
		
//		for(int i=0; i<cars.length; i++) {
//			//cars[0] in 1st iteration;
//			
//			//cars[1] in 2nd iteration;
//			
//			System.out.println("========================");
//			//temp.absWheels();
//			cars[i].brake();
//			cars[i].fuelCapacity(15);
//			cars[i].numDoors();
//			cars[i].speed();
//		}

		for(absCar temp: cars){
			
			System.out.println("========================");
			//temp.absWheels();
			temp.brake();
			temp.fuelCapacity(15);
			temp.numDoors();
			temp.speed();
			
		}
	}

}
