package DayFourPackage;

public class ThreadEx1 {
	public static void main(String[] args) {
		
		System.out.println("Thread Name " + Thread.currentThread().getName());
		
		System.out.println("Thread Priority " + Thread.currentThread().getPriority());
	}

}
