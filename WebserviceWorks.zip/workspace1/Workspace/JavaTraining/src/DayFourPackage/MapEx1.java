package DayFourPackage;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class MapEx1 {
	public static void main(String[] args) {
		Map<String, Integer> accounts = new HashMap<String, Integer>();
		
		accounts.put("abdul", 1000);
		accounts.put("suresh", 2000);
		accounts.put("peter", 3000);
		
		System.out.println("acct bal for Abdul -> " + accounts.get("abdul"));
		System.out.println("acct bal for suresh -> " + accounts.get("suresh"));
		System.out.println("acct bal for peter -> " + accounts.get("peter"));
		
		
		accounts.put("abdul", 12345);
		
		System.out.println("acct bal for Abdul -> " + accounts.get("abdul"));
		
		
		
		
		
		
		
		Set set = accounts.entrySet();
		Iterator itr = set.iterator();
		
		while (itr.hasNext()){
			
			Map.Entry<String, Integer> temp = (Entry<String, Integer>) itr.next();
			//String str = (String) itr.next();
			
			//System.out.println(str);
			
			System.out.println("Key -> " + temp.getKey()
			 + ", Value -> " + temp.getValue());
 		}
		
		
		
	}

}
