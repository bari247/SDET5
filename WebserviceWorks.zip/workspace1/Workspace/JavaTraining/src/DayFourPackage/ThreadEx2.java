package DayFourPackage;

class SampleThread extends Thread{

	
	// business logic goes here...
	// every job when it execute it is given a quantum time (or time slice) interval 4ms
	
	@Override
	public void run() {
		for(int i=0; i<50; i++){
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("i value " + i + " in thread " + Thread.currentThread().getName());
		}
		
		System.out.println("Thread " + Thread.currentThread().getName() + "  Exiting..");
	}
	// now this class is eligible to be async
	
	
}

public class ThreadEx2 {
	public static void main(String[] args) {
		// this will be the first thread
		//since it has main
		
		
		SampleThread st = new SampleThread();
		
		// thsi statmemnt shall create an OS level thread and give the control to 
		st.start();
		
		SampleThread st1 = new SampleThread();
		st1.start();
		
		SampleThread st2 = new SampleThread();
		st2.start();
		
		
		
		
		for(int i=0; i<50; i++){
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("i value " + i + " in thread " + Thread.currentThread().getName());
		}
		
		
		try {
			st.join();
			st1.join();
			st2.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("Thread " + Thread.currentThread().getName() + "  Exiting..");
		
		
		Runtime.getRuntime().gc();
	}

}
