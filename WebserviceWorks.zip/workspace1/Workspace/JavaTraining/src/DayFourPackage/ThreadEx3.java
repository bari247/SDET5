package DayFourPackage;


class BussinessLogic{}
class MyBussinessLogic extends BussinessLogic implements Runnable{

	Thread thread;
	int priority;
	MyBussinessLogic(String threadName, int priority){
		this.thread = new Thread(this, threadName);
		thread.setPriority(priority);
		// will create an OS level thread and invoke run
		thread.start();
	}
	
	public MyBussinessLogic() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		for(int i=0; i<40; i++){
			System.out.println("Thread " + Thread.currentThread().getName() + "has value " + 
		i + " Has the priority " + thread.getPriority());
		}
		
	}
	
}


public class ThreadEx3 {
	public static void main(String[] args) {
		
		MyBussinessLogic mbl = new MyBussinessLogic("Laptop ", Thread.MIN_PRIORITY);
		MyBussinessLogic mbl1 = new MyBussinessLogic("Mobile ",  Thread.NORM_PRIORITY);
		MyBussinessLogic mbl2 = new MyBussinessLogic("Projector ", Thread.MAX_PRIORITY);
		
		
		Thread tr1 = new Thread(new MyBussinessLogic());
		tr1.setName("Presenter");
		tr1.setPriority(mbl1.priority-2);
		tr1.start();
		
	}

}
