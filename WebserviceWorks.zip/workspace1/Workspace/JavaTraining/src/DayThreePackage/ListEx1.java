package DayThreePackage;

import java.util.ArrayList;
import java.util.List;

public class ListEx1 {
	public static void main(String[] args) {
		//
		List list = new ArrayList();
		
		list.add(10);
		list.add("hello");
		list.add(222.222);
		list.add(new Object(){});
		
		for(Object temp : list){
			System.out.println(temp);
		}
		
	}

}
