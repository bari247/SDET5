package DayThreePackage;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Queue;

public class QueueEx1 {
	public static void main(String[] args) {
		Queue q = new LinkedList<String>();
		
		q.offer("first");
		q.offer("second");
		q.offer("Third");
		q.offer("fourth");
		
		System.out.println(q);
		
		q.poll();
		q.poll();
		System.out.println(q);

		System.out.println(q.peek());
		System.out.println(q.peek());
		
		System.out.println(q);
		
		q.offer("Fifth");
		
		System.out.println(q);
			
		}
		
		
}


