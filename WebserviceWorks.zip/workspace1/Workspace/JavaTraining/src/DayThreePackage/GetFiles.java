package DayThreePackage;

import java.io.File;

public class GetFiles {
	public static void main(String[] args) {
		File f = new File("FannieTraining");
		File files [] = f.listFiles();
		
		for (File temp : files){
			if(temp.isFile() && temp.canWrite())
			System.out.println(temp.getName());
		}
				
		
		//System.out.println(f.isFile());
	}

}
