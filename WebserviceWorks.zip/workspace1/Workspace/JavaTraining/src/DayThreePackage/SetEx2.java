package DayThreePackage;

import java.util.HashSet;
import java.util.Set;

public class SetEx2 {
	public static void main(String[] args) {
		Set<Device> set = new HashSet<Device>();
		
		set.add(new Device(101, "Laptop", 2000));
		set.add(new Device(102, "Mobile", 1200));
		set.add(new Device(103, "Projector", 300));
		set.add(new Device(104, "AC", 5));
		set.add(new Device(105, "AC", 5));
		set.add(new Device(104, "AC", 5));
		
		for(Object temp : set){
			
			System.out.println(temp);
			
		}
		
	}

}
