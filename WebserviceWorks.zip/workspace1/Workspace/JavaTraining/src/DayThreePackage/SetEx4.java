package DayThreePackage;

import java.util.Set;
import java.util.TreeSet;

public class SetEx4 {
  public static void main(String[] args) {
  
   Set<Device> set = new TreeSet<Device>();

   set.add(new Device(101, "Laptop", 2000));
   set.add(new Device(222, "Mobile", 5000));
   set.add(new Device(333, "Projector", 3000));
   set.add(new Device(444, "Ac", 4000));
  
   set.forEach(System.out::println);
   
   
   
   TreeSet<Device> ts = new TreeSet<>(DeviceInDescending)
  
  }

}
