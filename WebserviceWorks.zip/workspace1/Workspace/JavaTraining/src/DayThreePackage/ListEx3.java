package DayThreePackage;

import java.util.Vector;

public class ListEx3 {
	public static void main(String[] args) {
		Vector<Integer> lst = new Vector<Integer>();
		
		int x = 5;
		
		System.out.println("Size " + lst.size());	
		System.out.println("Capacity " + lst.capacity());
		
		lst.add(100);
		lst.add(200);
		lst.add(x);
		
		
		System.out.println("Size " + lst.size());
		System.out.println("Capacity " + lst.capacity());
		
		lst.clear();
		System.out.println("Size " + lst.size());
		System.out.println("Capacity " + lst.capacity());
		
		
		
		
	}
}
