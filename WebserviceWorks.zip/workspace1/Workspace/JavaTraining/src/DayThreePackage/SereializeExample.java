package DayThreePackage;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import DayTwoPackage.Person;

public class SereializeExample {
	public static void storeObject (Person per){
		
		ObjectOutputStream oos = null;
		try {
			oos = new ObjectOutputStream( new FileOutputStream("pesron.ser"));
			
			oos.writeObject(per);
			oos.writeObject(new String("Fannie"));
			oos.writeDouble(10000);
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			try {
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		System.out.println("Data save successfully...");
	}

	
	public static void readObject() throws FileNotFoundException, IOException, ClassNotFoundException{
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("pesron.ser"));
		
		Person person = (Person) ois.readObject();
		
		System.out.println(person);
		
		ois.close();
				
				
	}
	
	public static void main(String[] args) {
		
//		Person p = new Person(101, "becky", 121);
//		storeObject(p);
		
		try {
			readObject();
		} catch (ClassNotFoundException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
