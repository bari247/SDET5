package DayThreePackage;

import java.util.Comparator;

import javax.annotation.Generated;

public class DeviceInDescending implements Comparator<Device> {
	
	
	@Override
	public int compare(Device o1, Device o2) {
		String first = (String) o1.getdName();
        String second = (String) o2.getdName();
        return second.compareTo(first);
	}
}
	

