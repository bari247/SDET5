package DayThreePackage;

import java.io.File;
import java.io.IOException;

public class FileProperties {
	public static void main(String[] args) throws IOException {
		
		//using file class will never create a file
		File f = new File("test.txt");
		f.createNewFile();
		//System.out.println(flag?"Create":"Note Created");
		
		System.out.println("Can Read ->" + f.canRead() );
		System.out.println("Can write ->" + f.canWrite() );
		System.out.println("is this file ->" + f.isFile() );
		
	}

}