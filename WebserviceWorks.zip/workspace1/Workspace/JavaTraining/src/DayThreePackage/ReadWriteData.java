package DayThreePackage;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;

// We read the data from user
// show it on console
// wite to a file
public class ReadWriteData {
	
	public static void main(String[] args) throws NumberFormatException, IOException {
		//read the data from console
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Entere Emp Id: ");
		int empId = Integer.parseInt(br.readLine());
		
		System.out.println("Enter Name : ");
		String empName = br.readLine();
		
		System.out.println("Enter Salary");
		double empSal = Double.parseDouble(br.readLine());
		
		String empInfo = "Employee Id of: " + empName + " is: " + empId + " And his salary is: " + empSal;
		
		System.out.println("----------- You Entered ---------------");
		System.out.println(empInfo);
		

		BufferedWriter bw = null;
				try{
					bw = new BufferedWriter(new FileWriter("Empt.txt", true));
					bw.newLine();
					bw.write(empInfo);
					
				}catch(IOException ioex){
					ioex.printStackTrace();
				}finally{
					bw.close();
					
				}	
		
	}

}
