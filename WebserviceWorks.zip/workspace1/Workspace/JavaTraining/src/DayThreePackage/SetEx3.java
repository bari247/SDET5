package DayThreePackage;

import java.util.TreeSet;

public class SetEx3 {
	public static void main(String[] args) {
		TreeSet<String> set = new TreeSet<String>();
		
		set.add("Deepti");
		set.add("Kawsar");
		set.add("Shashikanth");
		set.add("Sujakumar");
		
		System.out.println(set);
	}

}
