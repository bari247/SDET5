package DayTwoPackage;

import java.util.Arrays;

public class PersonSorter {
	public static void main(String[] args){
		Person [] pers = new Person[4];
		
		pers[0] = new Person(34, "Parag", 3434);
		pers[1] = new Person(12, "Sunitha", 7563);
		pers[2] = new Person(344, "Lakshmi", 2134);
		pers[3] = new Person(88, "Lisa", 4323);
		
		
		for(Person p : pers){
			System.out.println(p);
		}
		
		System.out.println("After Sort");
		System.out.println("=================");
		
		Arrays.sort(pers);
		
		
		//PersonSortDescName();
		
		
		for (Person p : pers){
			System.out.println(p);
		}
	}

}
