package DayTwoPackage;

public class Account {
	private int accID;
	private double balance;
	private String custName;
	
	private static int count = 100;
	
	public Account(double balance, String custName) {
		super();
		this.accID = count ++;
		this.balance = balance;
		this.custName = custName;
		
		
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public int getAccID() {
		return accID;
	}

	public String getCustName() {
		return custName;
	}
	
	

}
