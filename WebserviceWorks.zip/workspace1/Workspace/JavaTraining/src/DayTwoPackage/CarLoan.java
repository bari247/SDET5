package DayTwoPackage;

public class CarLoan implements BankLoan{

	@Override
	public void loanAmount(int amount) {
		System.out.println("Loan Ampunt is " + amount);
		
	}

	@Override
	public void repay(int amount) {
		System.out.println("You Repay " + amount);
		
	}

	@Override
	public void foreClosure() {
		System.out.println("You opted for forecolusre");
		
	}

}
