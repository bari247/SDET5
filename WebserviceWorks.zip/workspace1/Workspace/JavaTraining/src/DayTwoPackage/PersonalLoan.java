package DayTwoPackage;

public class PersonalLoan implements BankLoan{

	@Override
	public void loanAmount(int amount) {
		System.out.println("Personal Loan amount is" + amount);
		
	}

	@Override
	public void repay(int amount) {
		System.out.println("Personal Loan you reppay" + amount);
		
	}

	@Override
	public void foreClosure() {
		System.out.println("Peronal loan you opted for foreclousre");
		
	}

}
