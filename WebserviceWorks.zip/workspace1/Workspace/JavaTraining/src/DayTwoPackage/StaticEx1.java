package DayTwoPackage;

public class StaticEx1 {
	
	public int add(int num1, int num2){
		return num1 + num2;
	}
	
	public static void main(String[] args){
		StaticEx1 s = new StaticEx1();
		int res = s.add(10, 20);
		System.out.println("Result " + res);
	}

}
