package DayTwoPackage;

//import javax.management.RuntimeException;

public class ExceptionEx3 {
	public static void checkCreditScore(int cs, String name) throws FannieException{
		if (cs < 400){
			// throw exception
			throw new FannieException("Sorry less than 400 is processed, Mr/Mrs/Ms " + name);
			
		}else{
			System.out.println("We are good Mr/Mrs/Ms : " + name);
		}
	}
	
	
	public static void main(String[] args) {
		try{
		checkCreditScore(344, "harry");
		}catch(RuntimeException re){
			re.printStackTrace();
		} catch (FannieException e) {
			e.printStackTrace();
		}
		
		System.out.println("More logic here");
	}

}
