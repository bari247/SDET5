package DayTwoPackage;

public class ExceptionEx1 {
	public static void main(String[] args){
		try{
			int num1 = Integer.parseInt(args[0]);
			int num2 = Integer.parseInt(args[1]);
			
		int res = num1 / num2;
		System.out.println("REs " + res);
		}catch(NumberFormatException e){
			System.out.println("message : " + e);
		}
		
		System.out.println("I am some bussiness logic");
	}

}
