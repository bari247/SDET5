package DayTwoPackage;

public class ExceptionEx2 {
	public static void main(String[] args) {
		try{
			System.out.println("Connect to db");
			return;
		}catch(Exception e){
			System.out.println("Oh exception caught" + e);
		}finally{
			System.out.println("Close to db happens here");
		}
		System.out.println("I am other code int he world");
	}

}
