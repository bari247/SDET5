package DayTwoPackage;

public interface BankLoan {
	void loanAmount(int amount);
	void repay(int amount);
	void foreClosure();

}
