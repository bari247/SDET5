
public class AccountTest implements Runnable{
	
	Account account;
	int amt;
	
	public static void main(String[] args) {
		
		Account account  = new Account(1000);
		
		new AccountTest(account, 500, "Harry");
		new AccountTest(account, 750, "Larry");
		
	}

	@Override
	public void run() {
		synchronized (account) {
			account.withdraw(amt);
		}	
		
	}

	public AccountTest(Account account, int amt, String name) {
		
		Thread t = new Thread(this, name);
		this.account = account;
		this.amt = amt;
		
		
		t.start();
	}

}
