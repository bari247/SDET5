package com.SDETTraining;

public class TrainLoan {
	private int LoanId;
	private double loanAmount;
	private double interestRate;
	private String firstName;
	
	// setters and getters
	public void setLnId(int LoanId){
		this.LoanId = LoanId;
	}
	
	public void setLnAmnt (double lnAmount){
		this.loanAmount = lnAmount;
	}
	
	public void setIntRate (double intRate){
		this.interestRate = intRate;
	}
	
	public void setFrstName (String firstName){
		if (firstName.length()<5){
			System.out.println("Brrower name is less than 5 char");
			this.firstName = "No Name";
		}
		else{
			this.firstName = firstName;			
		}
		
	}

	public int getLoanId() {
		return LoanId;
	}

	public void setLoanId(int loanId) {
		LoanId = loanId;
	}

	public double getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(double loanAmount) {
		if(loanAmount < 10000){
			System.out.println("Sorry loan cannot be processed");
			this.loanAmount = 10000;
			System.out.println("Loan Amount is changed to  " + this.loanAmount);
		}
		else{
			this.loanAmount = loanAmount;
		}
		
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		if (firstName.length()<5){
	System.out.println("Brrower name is less than 5 char");
	this.firstName = "No Name";
}
else{
	this.firstName = firstName;
	}
	
	
	//////////////////
	
	
	
	}
	

}
