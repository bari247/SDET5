package com.SDETTraining;

public class Audi extends Car {
	
	public Audi() {
		System.out.println("Audi Constructed");
	}
	
	public void view(){
		System.out.println("Audi has rear view camera....");
	}

}
