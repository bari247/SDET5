package com.SDETTraining;

public class Vehicle {
	
	public Vehicle() {
		System.out.println("Vehicle created");
	}
	
	
	public void move(){
		System.out.println("All vehicles move....");
	}
	
	public void brake(){
		System.out.println("Vehicle applied break");
	}

}
