package com.SDETTraining;

public class LoanApplication {
	public static void main (String[] args){
		TrainLoan LoanForScott = new TrainLoan();
		
		LoanForScott.setLoanId(101); 
		LoanForScott.setInterestRate(5);
		LoanForScott.setFirstName("Sco");
		LoanForScott.setLoanAmount(3000);
		
		System.out.println("Loan ID is" + "  " +LoanForScott.getLoanId());
		System.out.println("Brrowers name is" + " " + LoanForScott.getFirstName());
		System.out.println("His interest rate is" + "  " + LoanForScott.getInterestRate());
		System.out.println("My Loan amount is" + LoanForScott.getLoanAmount());
	}

}
