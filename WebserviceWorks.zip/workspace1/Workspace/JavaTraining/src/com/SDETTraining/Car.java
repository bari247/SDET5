package com.SDETTraining;

public class Car extends Vehicle {
	
	public Car() {		
		System.out.println("Car Constructed");		
	}
	
	public void steering() {
		System.out.println("Car has steering");
	}
	
	public void fuelCapacity(int capacity) {
		System.out.println("Car fuel capacity" + capacity);
	}

}
