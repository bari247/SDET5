package com.SDETTraining;

public abstract class Figure {
	public abstract void area ();

}


class Rect extends Figure {
	int len;
	int bre;
	
	Rect (int len, int bre){
		this.len = len;
		this.bre = bre;
	}

	@Override
	public void area() {
		System.out.println("Area is " + (len * bre));
		
	}
	
}


class Sqr extends Figure{
	int len;
	Sqr (int len){
		this.len = len;
	}

	@Override
	public void area() {
		System.out.println("Area is " + (len * len));
		
	}
	
}