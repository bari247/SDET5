package com.fannie.step;


import java.util.List;
import java.util.Map;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStep{
	
	
	
	@After("@AfterSuccessLogin")
	@When("^user logs in successfully$")
	public void user_logs_in_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	
	@Given("^username and password$")
	public void username_and_password(DataTable dataTable)  throws Throwable{
		
		// we try displaying values passed as example in feature file
		List<Map<String, String>> dataList = dataTable.asMaps(String.class,String.class);
		
		for(Map<String,String> temp: dataList){
			System.out.println(temp);
		}
	    
	}

	@When("^login successful$")
	public void login_successful() {
		System.out.println("some test here ***********");
	}

	@Then("^show inbox$")
	public void show_inbox() {
		System.out.println("some test here ***********");
	}

}
