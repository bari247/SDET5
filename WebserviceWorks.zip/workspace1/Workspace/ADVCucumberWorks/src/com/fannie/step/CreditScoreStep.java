package com.fannie.step;

import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.But;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreditScoreStep {
	
	// this method is called hook method and call be called for all features.
	@Before
	public void conn_to_db(){
		System.out.println("===== connecting to DB ===========");
	}
	
	@Given("^load chrome browser$")
	public void load_chrome_browser() throws Throwable {
	    System.out.println(":::::: Chrome browser loading :::::::::");
	}
	
	@Given("Employee has a credit score")
	public void Employee_has_a_credit_score(){
		System.out.println("Employee has a credit score >>>>>>");
	}
	
	@And("it meets the bank standards")
	public void it_meets_the_bank_standards(){
		System.out.println("Emplee meets bank standars.....");
	}
	
	
	@When("^customer has \"([a-zA-Z]{1,})\" time job$")
	public void customer_has_full_time_job(String workTime){
		System.out.println("customer has -"+ workTime+ "- time job>>>>>>>>>");
	}
	
	@And ("is a (\"[a-zA-Z]{1,}\") employee")
	public void is_a_govt_employee(String officeType){
		System.out.println("in "+officeType+" office>>>>>>>>>");
		
	}
	
	
	@Then ("sanction")
	public void sanction(){
		System.out.println("sanction loan >>>>>");
	}
	
	
	@But ("Should repay within (\"[0-9]{1,}\") years")
	public void Should_repay_within_5_years(String noOfYears){
		System.out.println("Should repay within "+ noOfYears +"years>>>>>>>>>");		
	}
	
	
	@And ("is a private employee")
	public void is_a_private_employee(){
		
	}

}
