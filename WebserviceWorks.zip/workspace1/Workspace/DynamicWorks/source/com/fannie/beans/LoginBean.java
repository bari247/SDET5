package com.fannie.beans;

public class LoginBean {
	
	private String uName;
	private String password;
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
	// to string
	@Override
	public String toString() {
		return "LoginBean [uName=" + uName + ", password=" + password + "]";
	}
	

}
