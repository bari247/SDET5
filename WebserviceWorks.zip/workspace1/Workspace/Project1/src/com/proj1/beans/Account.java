package com.proj1.beans;

public class Account {
	
	private int acctId;
	private int acctNum;
	private int acctBal;
	private int avgBal;
	
	// getters and setters
	
	public int getAcctId() {
		return acctId;
	}
	public void setAcctId(int acctId) {
		this.acctId = acctId;
	}
	public int getAcctNum() {
		return acctNum;
	}
	public void setAcctNum(int acctNum) {
		this.acctNum = acctNum;
	}
	public int getAcctBal() {
		return acctBal;
	}
	public void setAcctBal(int acctBal) {
		this.acctBal = acctBal;
	}
	public int getAvgBal() {
		return avgBal;
	}
	public void setAvgBal(int avgBal) {
		this.avgBal = avgBal;
	}
	
	
	
	// to string
	@Override
	public String toString() {
		return "Account [acctId=" + acctId + ", acctNum=" + acctNum + ", acctBal=" + acctBal + ", avgBal=" + avgBal
				+ "]";
	}
	
	
	//constructors
	
	public Account(){}
	
	
	public Account(int acctId, int acctNum, int acctBal, int avgBal) {
		super();
		this.acctId = acctId;
		this.acctNum = acctNum;
		this.acctBal = acctBal;
		this.avgBal = avgBal;
	}
	
	
	
	

	
	

}
