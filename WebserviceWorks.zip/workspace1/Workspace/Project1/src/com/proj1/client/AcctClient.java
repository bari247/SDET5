package com.proj1.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import com.proj1.beans.Account;
import com.proj1.contract.IAcctDAO;
import com.proj1.dao.AcctDAO;

public class AcctClient {
	public static void main(String[] args) throws NumberFormatException, IOException {
		IAcctDAO dao = new AcctDAO();
		int tempAcctId = 0;
		int avgBal = 0;
		
		BufferedReader br1 = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please choose from the following options: ");
		System.out.println("1. To display all the accounts information, enter '1': ");
		System.out.println("2. To display account information, and update average balance, enter '2': ");
		
		int usrChoice = Integer.parseInt(br1.readLine());
					
		if(usrChoice == 1){
			int i = 0;
			for(Account temp: dao.getAllAcct()){
				i++;							
				System.out.println(temp);
								
				if(i == dao.getAllAcct().size()){
					System.out.println("---- End Of Accounts--------");
				}				
			}			
		}else if(usrChoice == 2){
			int x = 0;
			for(Account temp: dao.getAllAcct()){
				x++;
				System.out.println(temp);
				tempAcctId = temp.getAcctId();
				
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.println("Entere the percentage: ");
				String rdrInput = br.readLine();
				if(rdrInput.length() > 0){
					avgBal = Integer.parseInt(rdrInput);					
				}else{
					avgBal = 0;
				}
				
				if(rdrInput.length() > 0){
					
					dao.updateAcct(tempAcctId, avgBal);
					
				}else{
					System.out.println("You did not enter any value for avg balance. We will continue without updating data");
				}
				
				if (x == dao.getAllAcct().size()){
					System.out.println("------ You have iterated through all the accounts ---------");
				}
				
			}			
		}		
	}

}
