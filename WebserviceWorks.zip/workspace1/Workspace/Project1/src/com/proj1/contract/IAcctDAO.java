package com.proj1.contract;

import java.util.List;
import com.proj1.beans.Account;

public interface IAcctDAO {
	
	//Insert
		public boolean insertAcct(Account emp);
		
		//delete
		public boolean deleteAcct(int empID);
		
		//get 1 employee
		public Account getAcct(int empID);
		
		
		//get all
		public List<Account> getAllAcct();
		

		//update
		boolean updateAcct(int acctId, int salary);

}
