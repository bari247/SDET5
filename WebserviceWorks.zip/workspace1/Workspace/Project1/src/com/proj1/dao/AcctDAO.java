package com.proj1.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.proj1.beans.Account;
import com.proj1.connection.getConnection;
import com.proj1.contract.IAcctDAO;

public class AcctDAO implements IAcctDAO{

	@Override
	public boolean insertAcct(Account acct) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateAcct(int acctId, int salary) {
		String sql = "update account set avg_bal = "+ salary +" where id = " + acctId;
		
		getConnection gc = new getConnection();

		try {
			gc.ps = getConnection.getMySQLConnection().prepareStatement(sql);
			//gc.ps.setInt(, salary);
			//gc.ps.setInt(salary, acctId);

			if (gc.ps.executeUpdate() > 0) {
				return true;
			} else {
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean deleteAcct(int acctID) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account getAcct(int acctID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAllAcct() {
		// listing out all accounts;
		String sql = "select id, acct_no, balance, avg_bal from account";
		getConnection gc = new getConnection();
		
		List<Account> accList = new ArrayList<Account>();
		
		try {
			// setting connection and preparing statement.
			gc.ps = getConnection.getMySQLConnection().prepareStatement(sql);
			
			//getting all the results
			gc.rs = gc.ps.executeQuery();
			
			while (gc.rs.next()){
				
				Account temp = new Account();
				temp.setAcctId(gc.rs.getInt(1));
				temp.setAcctNum(gc.rs.getInt(2));
				temp.setAcctBal(gc.rs.getInt(3));
				temp.setAvgBal(gc.rs.getInt(4));
				
				accList.add(temp);
			}
			
			return accList;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
