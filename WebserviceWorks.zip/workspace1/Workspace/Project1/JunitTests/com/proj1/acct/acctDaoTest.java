package com.proj1.acct;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.proj1.contract.IAcctDAO;
import com.proj1.dao.AcctDAO;

public class acctDaoTest {

	//@SuppressWarnings("deprecation")
	@Test
	public void acctUpdateTest() {
		
			try {
				IAcctDAO dao = new AcctDAO();
				long start = System.currentTimeMillis();
				dao.updateAcct(1, 14);
				//Thread.sleep(100);
				long end = System.currentTimeMillis();
				
				Assert.assertTrue("Greater than 100 milli secs", ((end - start) < 100));
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
